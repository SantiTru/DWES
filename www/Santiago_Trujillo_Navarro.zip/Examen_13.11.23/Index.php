<!DOCTYPE html>
<html>

<head>
  <title>Examen 13.11.23</title>
  <meta charset="UTF-8" />
</head>

<body>

  <h1>La carta mayor gana!</h1>

  <h4>Decidme vuestros nombre:</h4>

  <form action="tirada.php" method="post">
    <label for="jugador1">Jugador 1:</label>
    <input type="text" name="jugador1" required>
    <br>
    <br>
    <label for="jugador2">Jugador 2:</label>
    <input type="text" name="jugador2" required>
    <br>
    <br>
    <input type="submit" value="Jugar">
  </form>

</body>

</html>
